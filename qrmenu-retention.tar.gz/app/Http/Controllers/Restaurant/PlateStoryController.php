<?php

namespace App\Http\Controllers\Restaurant;

use App\Console\Commands\CleanupPlateStories;
use App\Http\Controllers\Controller;
use App\Models\MenuEvent;
use App\Models\PlateStory;
use App\Services\ImageStore;
use App\Services\PlanLimits;
use App\Services\PlateStorySettings;
use App\Support\CurrentRestaurant;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class PlateStoryController extends Controller
{
    public function index(Request $request, CurrentRestaurant $current): Response
    {
        Gate::authorize('manage-plate-story');
        $restaurant = $current->get();
        $status = in_array($request->query('status'), ['pending', 'approved', 'hidden'], true) ? $request->query('status') : 'pending';
        $since = now()->subDays(30);

        return Inertia::render('restaurant/plate-story/index', [
            'settings' => PlateStorySettings::for($restaurant),
            'available' => PlanLimits::for($restaurant)->has('plate_story'),
            'instagram' => $restaurant->instagram_handle,
            'languages' => $restaurant->languages,
            'status' => $status,
            // Stories whose photos were already cleaned up are left out of the lists (they still count in the stats).
            'counts' => [
                'pending' => PlateStory::where('status', 'pending')->whereNull('photos_deleted_at')->count(),
                'approved' => PlateStory::where('status', 'approved')->whereNull('photos_deleted_at')->count(),
                'hidden' => PlateStory::where('status', 'hidden')->whereNull('photos_deleted_at')->count(),
            ],
            'retention' => [
                'pending_days' => CleanupPlateStories::PENDING_DAYS,
                'hidden_days' => CleanupPlateStories::HIDDEN_DAYS,
                'keep_per_dish' => CleanupPlateStories::KEEP_PER_DISH,
            ],
            'stats' => [
                'created' => PlateStory::where('created_at', '>=', $since)->count(),
                'shared' => PlateStory::where('created_at', '>=', $since)->whereNotNull('shared_at')->count(),
                'visits' => MenuEvent::where('event', 'menu_view')->where('source', 'story')->where('created_at', '>=', $since)->count(),
                'redeemed' => PlateStory::where('reward_redeemed_at', '>=', $since)->count(),
            ],
            'stories' => PlateStory::query()
                ->where('status', $status)
                ->whereNull('photos_deleted_at')
                ->with('item:id,name')
                ->latest()
                ->paginate(24)
                ->withQueryString()
                ->through(fn (PlateStory $s) => [
                    'id' => $s->id,
                    'status' => $s->status,
                    'dish' => $s->item?->translate('name', $restaurant->main_language),
                    'before_url' => ImageStore::url($s->before_path),
                    'after_url' => ImageStore::url($s->after_path),
                    'shared' => (bool) $s->shared_at,
                    // When the nightly clean-up will delete this photo (waiting and hidden photos only).
                    'removes_at' => match ($s->status) {
                        'pending' => $s->created_at->copy()->addDays(CleanupPlateStories::PENDING_DAYS)->toIso8601String(),
                        'hidden' => $s->updated_at->copy()->addDays(CleanupPlateStories::HIDDEN_DAYS)->toIso8601String(),
                        default => null,
                    },
                    'created_at' => $s->created_at->toIso8601String(),
                ]),
        ]);
    }

    public function updateSettings(Request $request, CurrentRestaurant $current): RedirectResponse
    {
        Gate::authorize('manage-plate-story');
        $data = $request->validate([
            'enabled' => ['boolean'],
            'ask_after_photo' => ['boolean'],
            'card_styles' => ['required', 'array', 'min:1'],
            'card_styles.*' => [Rule::in(PlateStorySettings::STYLES)],
            'caption' => ['array'],
            'caption.*' => ['nullable', 'string', 'max:60'],
            'reward_enabled' => ['boolean'],
            'reward_text' => ['array'],
            'reward_text.*' => ['nullable', 'string', 'max:80'],
            'reward_days' => ['required', 'integer', 'between:1,365'],
            'reward_limit' => ['required', Rule::in(array_keys(PlateStorySettings::LIMITS))],
        ]);

        if (($data['reward_enabled'] ?? false) && ! array_filter($data['reward_text'] ?? [])) {
            return back()->withErrors(['reward_text' => 'Describe the reward, e.g. “Free karak on your next visit”.']);
        }

        $restaurant = $current->get();
        $settings = $restaurant->settings ?? [];
        $settings['plate_story'] = $data;
        $restaurant->update(['settings' => $settings]);
        $this->toast('Plate Story settings saved.');

        return back();
    }

    public function moderate(Request $request, PlateStory $story): RedirectResponse
    {
        Gate::authorize('manage-plate-story');
        $story->update($request->validate(['status' => ['required', Rule::in(['approved', 'hidden', 'pending'])]]));

        return back();
    }

    /** Staff type the code a guest shows them. */
    public function redeem(Request $request): RedirectResponse
    {
        Gate::authorize('manage-plate-story');
        $code = strtoupper(trim((string) $request->validate(['code' => ['required', 'string', 'max:20']])['code']));
        $story = PlateStory::where('reward_code', $code)->first(); // tenant-scoped

        if (! $story) {
            $this->toast("No reward found for code {$code}.", 'error');
        } elseif ($story->reward_redeemed_at) {
            $this->toast("Code {$code} was already used on {$story->reward_redeemed_at->format('d M, H:i')}.", 'error');
        } elseif ($story->reward_expires_at && $story->reward_expires_at->isPast()) {
            $this->toast("Code {$code} expired on {$story->reward_expires_at->format('d M')}.", 'error');
        } else {
            $story->update(['reward_redeemed_at' => now()]);
            $this->toast("Code {$code} is valid — reward redeemed.");
        }

        return back();
    }
}
