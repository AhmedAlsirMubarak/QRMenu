<?php

namespace Tests\Feature\Platform;

use App\Actions\Restaurants\CreateRestaurant;
use App\Models\Payment;
use App\Models\Restaurant;
use App\Models\SiteSetting;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Notifications\BillingDigest;
use App\Notifications\InvoiceReminder;
use App\Notifications\PlanExpiring;
use App\Support\CurrentRestaurant;
use Database\Seeders\PlanSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Notification;
use Tests\TestCase;

class BillingRemindersTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(PlanSeeder::class);
        config(['qrmenu.timezone' => 'Asia/Muscat']);
        Carbon::setTestNow(Carbon::parse('2026-11-10 09:00', 'Asia/Muscat'));
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        parent::tearDown();
    }

    /** @return array{0: User, 1: Restaurant} */
    protected function restaurant(): array
    {
        $owner = User::factory()->create();
        $r = app(CreateRestaurant::class)->handle($owner, ['name' => 'Bait', 'main_language' => 'en', 'currency' => 'OMR', 'plan_id' => SubscriptionPlan::where('slug', 'starter')->value('id')]);
        app(CurrentRestaurant::class)->set(null);

        return [$owner, $r];
    }

    public function test_trial_ending_in_three_days_emails_the_owner_once(): void
    {
        Notification::fake();
        [$owner, $r] = $this->restaurant();
        $r->subscription->update(['trial_ends_at' => Carbon::parse('2026-11-13 18:00', 'Asia/Muscat')]);

        $this->artisan('reminders:send')->assertSuccessful();
        $this->artisan('reminders:send')->assertSuccessful(); // second run the same day: nothing new

        Notification::assertSentToTimes($owner, PlanExpiring::class, 1);
        Notification::assertSentTo($owner, PlanExpiring::class, fn ($n) => $n->daysLeft === 3);
    }

    public function test_ended_plan_and_invoice_stages_are_sent(): void
    {
        Notification::fake();
        [$owner, $r] = $this->restaurant();
        $r->subscription->update(['status' => 'expired', 'trial_ends_at' => Carbon::parse('2026-11-09 12:00', 'Asia/Muscat')]);

        $due = Payment::create(['restaurant_id' => $r->id, 'invoice_number' => 'INV-1', 'amount' => 6, 'currency' => 'OMR', 'status' => 'pending', 'due_date' => '2026-11-10']);
        $late = Payment::create(['restaurant_id' => $r->id, 'invoice_number' => 'INV-2', 'amount' => 6, 'currency' => 'OMR', 'status' => 'overdue', 'due_date' => '2026-11-07']);
        Payment::create(['restaurant_id' => $r->id, 'invoice_number' => 'INV-3', 'amount' => 6, 'currency' => 'OMR', 'status' => 'paid', 'due_date' => '2026-11-10']);

        $this->artisan('reminders:send')->assertSuccessful();

        Notification::assertSentTo($owner, PlanExpiring::class, fn ($n) => $n->daysLeft === 0);
        Notification::assertSentTo($owner, InvoiceReminder::class, fn ($n) => $n->payment->is($due) && $n->stage === 'today');
        Notification::assertSentTo($owner, InvoiceReminder::class, fn ($n) => $n->payment->is($late) && $n->stage === 'overdue');
        Notification::assertSentToTimes($owner, InvoiceReminder::class, 2);
    }

    public function test_admin_digest_goes_to_support_email_and_settings_can_turn_reminders_off(): void
    {
        Notification::fake();
        SiteSetting::put('support_email', 'billing@qrmenu.test');
        [$owner, $r] = $this->restaurant();
        $r->subscription->update(['trial_ends_at' => Carbon::parse('2026-11-13 18:00', 'Asia/Muscat')]);
        SiteSetting::put('notify_plan_expiry', false);

        $this->artisan('reminders:send')->assertSuccessful();

        Notification::assertNotSentTo($owner, PlanExpiring::class);
        Notification::assertSentOnDemand(BillingDigest::class, fn ($n, $c, $notifiable) => $notifiable->routes['mail'] === 'billing@qrmenu.test' && count($n->expiring) === 1);
    }
}
