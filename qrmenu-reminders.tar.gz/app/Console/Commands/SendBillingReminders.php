<?php

namespace App\Console\Commands;

use App\Models\Payment;
use App\Models\SiteSetting;
use App\Models\Subscription;
use App\Models\User;
use App\Notifications\BillingDigest;
use App\Notifications\InvoiceReminder;
use App\Notifications\PlanExpiring;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

/**
 * Daily emails about money:
 *  - restaurant owners: plan/trial ending in 7, 3 and 1 days, and when it has ended;
 *  - restaurant owners: invoice due in 3 days, due today, and overdue (3 and 7 days late);
 *  - platform team: one summary of everything above (to the support email).
 * Every reminder is logged in sent_reminders so it is only ever sent once.
 */
class SendBillingReminders extends Command
{
    public const PLAN_DAYS = [7, 3, 1];

    protected $signature = 'reminders:send {--dry-run : List what would be sent without emailing}';

    protected $description = 'Email reminders for expiring plans and unpaid invoices';

    protected int $sent = 0;

    public function handle(): int
    {
        $today = Carbon::now(config('qrmenu.timezone'))->startOfDay();

        if (SiteSetting::get('notify_plan_expiry', true)) {
            $this->planReminders($today);
        }
        if (SiteSetting::get('notify_invoices', true)) {
            $this->invoiceReminders($today);
        }
        if (SiteSetting::get('notify_admin_digest', true)) {
            $this->adminDigest($today);
        }

        $this->info("Reminders sent: {$this->sent}");

        return self::SUCCESS;
    }

    protected function planReminders(Carbon $today): void
    {
        Subscription::withoutRestaurantScope()
            ->whereIn('status', ['trialing', 'active', 'past_due', 'expired'])
            ->with(['restaurant', 'plan'])
            ->get()
            // Only the restaurant's current subscription, and only restaurants still in business.
            ->filter(fn (Subscription $s) => $s->restaurant && $s->restaurant->status === 'active' && $s->restaurant->subscription?->is($s))
            ->each(function (Subscription $s) use ($today) {
                $end = $s->status === 'trialing' || ($s->status === 'expired' && ! $s->ends_at) ? $s->trial_ends_at : $s->ends_at;
                if (! $end) {
                    return;
                }
                $endDay = $end->copy()->setTimezone(config('qrmenu.timezone'))->startOfDay();
                $daysLeft = (int) $today->diffInDays($endDay, false);

                if (in_array($daysLeft, self::PLAN_DAYS, true) && in_array($s->status, ['trialing', 'active'], true)) {
                    $this->once("plan:{$s->id}:{$endDay->toDateString()}:{$daysLeft}d", fn () => $this->notifyOwners($s->restaurant_id, new PlanExpiring($s, $daysLeft)));
                } elseif ($daysLeft <= 0 && $daysLeft >= -2 && in_array($s->status, ['past_due', 'expired'], true)) {
                    // Sent once, within two days of the end date (so a missed run still catches it).
                    $this->once("plan:{$s->id}:{$endDay->toDateString()}:ended", fn () => $this->notifyOwners($s->restaurant_id, new PlanExpiring($s, 0)));
                }
            });
    }

    protected function invoiceReminders(Carbon $today): void
    {
        Payment::query()
            ->whereNotNull('restaurant_id')->whereNotNull('due_date')
            ->whereIn('status', ['pending', 'overdue'])
            ->with('restaurant')
            ->get()
            ->each(function (Payment $p) use ($today) {
                // Compare calendar dates only (due dates have no time or time zone). >0 = days until due.
                $days = (int) Carbon::parse($today->toDateString())->diffInDays(Carbon::parse($p->due_date->toDateString()), false);

                $stage = match (true) {
                    $days === 3 => ['soon', 'due-3d'],
                    $days === 0 => ['today', 'due-0d'],
                    $days === -3 => ['overdue', 'late-3d'],
                    $days === -7 => ['overdue', 'late-7d'],
                    default => null,
                };

                if ($stage) {
                    $this->once("invoice:{$p->id}:{$stage[1]}", fn () => $this->notifyOwners($p->restaurant_id, new InvoiceReminder($p, $stage[0])));
                }
            });
    }

    protected function adminDigest(Carbon $today): void
    {
        $to = SiteSetting::get('support_email');
        if (! $to) {
            return;
        }

        $subs = Subscription::withoutRestaurantScope()->with(['restaurant:id,name,status', 'plan:id,name'])
            ->whereIn('status', ['trialing', 'active', 'past_due', 'expired'])->get()
            ->filter(fn ($s) => $s->restaurant && $s->restaurant->status === 'active');

        $endOf = fn (Subscription $s) => ($s->status === 'trialing' || ($s->status === 'expired' && ! $s->ends_at) ? $s->trial_ends_at : $s->ends_at)?->copy()->setTimezone(config('qrmenu.timezone'))->startOfDay();

        $expiring = $subs->filter(fn ($s) => in_array($s->status, ['trialing', 'active'], true) && ($e = $endOf($s)) && $e->between($today, $today->copy()->addDays(7)))
            ->map(fn ($s) => ['restaurant' => $s->restaurant->name, 'plan' => $s->plan?->translate('name') ?? '—', 'date' => $endOf($s)->format('j M'), 'status' => $s->status === 'trialing' ? 'trial' : 'paid'])->values()->all();

        $ended = $subs->filter(fn ($s) => in_array($s->status, ['past_due', 'expired'], true) && ($e = $endOf($s)) && $e->equalTo($today->copy()->subDay()))
            ->map(fn ($s) => ['restaurant' => $s->restaurant->name, 'plan' => $s->plan?->translate('name') ?? '—', 'date' => $endOf($s)->format('j M')])->values()->all();

        $unpaid = Payment::with('restaurant:id,name')->whereIn('status', ['pending', 'overdue'])->orderBy('due_date')->limit(50)->get()
            ->map(fn (Payment $p) => [
                'invoice' => $p->invoice_number,
                'client' => $p->restaurant?->name ?? $p->payer_name ?? '—',
                'amount' => number_format((float) $p->amount, 3).' '.$p->currency,
                'due' => $p->due_date?->format('j M') ?? '—',
                'overdue' => $p->displayStatus() === 'overdue' || $p->status === 'overdue',
            ])->all();

        if ($expiring === [] && $ended === [] && $unpaid === []) {
            return;
        }

        $this->once("digest:{$today->toDateString()}", fn () => Notification::route('mail', $to)->notify(new BillingDigest($expiring, $ended, $unpaid)));
    }

    protected function notifyOwners(int $restaurantId, \Illuminate\Notifications\Notification $notification): void
    {
        $owners = User::query()->whereHas('restaurants', fn ($q) => $q->whereKey($restaurantId)->where('restaurant_user.role', 'owner'))->get();
        Notification::send($owners, $notification);
    }

    /** Runs $send once per key; failures are logged and retried on the next run. */
    protected function once(string $key, callable $send): void
    {
        if (DB::table('sent_reminders')->where('key', $key)->exists()) {
            return;
        }

        if ($this->option('dry-run')) {
            $this->line("Would send: {$key}");

            return;
        }

        try {
            $send();
            DB::table('sent_reminders')->insert(['key' => $key, 'sent_at' => now()]);
            $this->sent++;
        } catch (\Throwable $e) {
            Log::warning('Billing reminder failed', ['key' => $key, 'error' => $e->getMessage()]);
        }
    }
}
